<?php
use PHPMailer\PHPMailer\PHPMailer;
require_once "PHPMailer/PHPMailer.php";
require_once "PHPMailer/SMTP.php";
require_once "PHPMailer/Exception.php";

$mail = new PHPMailer(true);
$alert = '';

if(isset($_POST['submit']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    try{
        $mail-> SMTP::DEBUG_SERVER;
        $mail -> isSMTP();
        $mail -> Host = "smtp.gmail.com";
        $mail -> SMTPAuth = true;
        $mail -> Username = "mnsongirkar@gmail.com";
        $mail -> Password = 'mansi@711#9';
        $mail -> Port = 587;
        $mail -> SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;

        $mail -> setFrom('mansisongirkar990740@gmail.com');
        $mail-> addAddress("msongirkar@gmail.com");
        $mail-> subject  = 'Message Recieved (Contact Page)';
        $mail-> Body = '<h3>Name: $name <br> Email: $email <br> Message: $message</h3>';
        $mail ->isHTML(true);

        $mail-> send();
        $alert = '';
       $alert = '<div class="alert-success"><span>Messge Sent! Thankyou for contacting us</span></div>';

    
    } catch (Exception $e)
    {
        $alert = '<div class="alert-error"><span>'.$e-> getMessage().'</span></div>';
    }

}


?>
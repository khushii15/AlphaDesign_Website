<?php
include("connection.php");
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- custom css file link  -->
    <link rel="stylesheet" href="style.css">

</head>
<body>

<div class="container">
   
    <form action="" method="post">
    <?php
    $cart_item = mysqli_query($conn,"SELECT * FROM `products`");
    $total =0;
    $grand_total =0;
    if(mysqli_num_rows($cart_item)>0)
    {
        while($cart_item = mysqli_fetch_assoc($cart_item))
        {
            $total_price = number_format($cart_item['price']*$cart_item['quantity']);
            $grand_total = $total += $total_price;
            ?>
            <span><?php $cart_item['name'];?><?php $cart_item['quantity'];?></span>
            <?php
        }
    } 
    else{
            echo "<div class='display-order'><span>Your cart is empty!</span></div>";

        }
        
   
  
    ?>
    <span class='grand-total'>grand total: <?php $grand_total;?></span>


        <div class="row">

            <div class="col">

                <h3 class="title">billing address</h3>

                <div class="inputBox">
                    <span>full name :</span>
                    <input type="text" placeholder="john deo">
                </div>
                <div class="inputBox">
                    <span>email :</span>
                    <input type="email" placeholder="example@example.com">
                </div>
                <div class="inputBox">
                    <span>address :</span>
                    <input type="text" placeholder="room - street - locality">
                </div>
                <div class="inputBox">
                    <span>city :</span>
                 <select name="city" id="city" style="width:100%; font-size: 15px; border:1px solid #ccc; padding:10px 15px; text-transform: none;">
                    <option value="">Burhanpur</option>
                 </select>
                    <!-- <ul class="dropdown-menu">
              <li>Burhanpur</li> -->
                </ul>
                </div>

                <div class="flex">
                    <div class="inputBox">
                        <span>state :</span>
                        <select name="state" id="state" style="width:100%; font-size: 15px; border:1px solid #ccc; padding:10px 15px; text-transform: none;">
                    <option value="">M.P</option>
                 </select>
                    </div>
                    <div class="inputBox">
                        <span>Pincode :</span>
                        <select name="pincode" id="pincode" style="width:100%; font-size: 15px; border:1px solid #ccc; padding:10px 15px; text-transform: none;">
                    <option value="">450331</option>
                 </select>
                    </div>
                </div>

            </div>

            <div class="col">

                <h3 class="title">payment</h3>
                <!-- <div class="input-box">
                    <span>Payment Method</span>
                    <select name="method" id="">
                       
                        <option value="">credit card</option>
                        <option value="">paypal</option>
                    </select>
                </div> -->

                <div class="inputBox">
                    <span>cards accepted :</span>
                    <img src="images/card_img.png" alt="">
                </div>
                <div class="inputBox">
                    <span>name on card :</span>
                    <input type="text" placeholder="mr. john deo">
                </div>
                <div class="inputBox">
                    <span>credit card number :</span>
                    <input type="number" placeholder="1111-2222-3333-4444">
                </div>
                <div class="inputBox">
                    <span>exp month :</span>
                    <input type="text" placeholder="january">
                </div>

                <div class="flex">
                    <div class="inputBox">
                        <span>exp year :</span>
                        <input type="number" placeholder="2022">
                    </div>
                    <div class="inputBox">
                        <span>CVV :</span>
                        <input type="text" placeholder="1234">
                    </div>
                </div>

            </div>
    
        </div>

        <input type="submit" value="proceed to checkout" class="submit-btn">

    </form>

</div>    
    
</body>
</html>
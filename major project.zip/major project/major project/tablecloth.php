

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alpha Design</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

  <link
    href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Tangerine&family=Tiro+Telugu&display=swap"
    rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

  <link rel="stylesheet" href="card.css">
  <link rel="stylesheet" href="trial.css">
  <link rel="stylesheet" href="index.css">

</head>

<body>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <?php
 include('header.php');
 ?>
  <main>
    <div class="subtitles">passion for home decoration</div>
    <div class="titles">Products</div>
    <div class="container1">
      <div class="row center">
      <?php
                      include('connection.php');
                    $query = "SELECT * FROM `tablecloth`";
                    $result = mysqli_query($conn, $query);
                    if (!empty($result)) {
                        while ($product = mysqli_fetch_array($result))
                         {
                            ?>
                          <div class="col-sm-6 col-md-4 col-lg-3 ">
                            <form action="cart.php?action=add&pid=<?= $product['id']; ?>" method="post">
                                <!-- <div class="card border-light mb-3"> -->
                                  <img src="<?= $product['images']; ?>" class=" img11">
                                    <!-- <div class="card-body"> -->
                                    <input type="hidden" name="code" value="<?php echo $product['code']; ?>"/>  
                                    <h5 class="center pcategory" ><?php echo $product['name']; ?></h5>
                                    <p class="center">
                                      <span>₹<?= number_format($product['price'], 2); ?></span><br>
                                      <input type="number" name="quantity" value="1" size="2"><br><br>
                                        <input type="submit" value="Add to Cart" class="btn btn-success btn-sm">
                                       

                                    </p>
                                    <!-- </div> -->
                                <!-- </div> -->
                         </form>
                            </div>

                            <?php

                            
                         }
                        }
                        else {
                            echo "no products available";
                        }
                             ?>
        </div> 
            </div>
            </div>
            </div>
            </div>

<?php
include('footer.php');
?>

   
   







      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
        crossorigin="anonymous"></script>
      <script src="https://kit.fontawesome.com/76632d8e3c.js" crossorigin="anonymous"></script>
      <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
          integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2"
          crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"
          integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk"
          crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js"
          integrity="sha384-kjU+l4N0Yf4ZOJErLsIcvOU2qSb74wXpOhqTvwVx3OElZRweTnQ6d31fXEoRD1Jy"
          crossorigin="anonymous"></script> -->


</body>
</html>

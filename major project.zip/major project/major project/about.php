
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alpha Design</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

  <link
    href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Tangerine&family=Tiro+Telugu&display=swap"
    rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Lobster&family=Nunito:wght@500&family=Tiro+Telugu&display=swap" rel="stylesheet">
<link rel="stylesheet" href="index.css">


</head>

<body>
 <?php
 include('header.php');
 ?>
  <div class="aboutdiv"> 
      <p class="abouttext"> We provide Home Decoration items which are all handmade in which
           we provide cushions, Macrame Mirror in mandala designs, which will definitely make
            your walls look aesthetic. macrame purse of diffrent varietirs, beautiful plant
             holders and also macrame Wall Hangings to decorate yourv room in a unique way.<br>
             <br>

          All macrame home decors, dream catchers, plant hangers which we provide are handmade
     We procure all the raw materials locally.<br><br>

         We at alphadesign try to provide custom designs as well. This means if you have some
     design in your mind or you like something from our store but want some changes to it you can write to us and we will get it done for you if possible. </p>

  </div>
<!-- <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, distinctio aliquid alias eligendi aspernatur tempore veniam, laborum, beatae ipsa nulla dolor perspiciatis nisi dicta quae! Suscipit dicta perferendis cumque repellendus!
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit velit qui numquam delectus sint consectetur dolores quas, hic dicta soluta facere. Facere culpa qui perspiciatis ex ullam tempora neque corrupti?
</div>
<div>
  Lorem, ipsum dolor sit amet consectetur adipisicing elit. Enim suscipit aut soluta harum totam odit veritatis molestiae hic sint architecto magnam provident, est sit itaque ipsam nesciunt tenetur consequuntur eaque.

</div> -->
<br>
<br>
<br><br><br><br><br><br><br>

<?php
include('footer.php');
?>
      






      





     


</body>

</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>product</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <?php
    include('header.php');
    ?>
    <?php
    include('connection.php');
    ?>
     <div class="subtitles">passion for home decoration</div>
    <div class="titles">Products</div>
    <?php
   $query = "SELECT * FROM `products` WHERE  ";
   $result = mysqli_query($conn, $query);
   $product = mysqli_fetch_array($result);
   ?>
   <div class="col-sm-6 col-md-4 col-lg-3 ">
   <form action="cart.php?action=add&pid=<?= $product['id']; ?>" method="post">
       <!-- <div class="card border-light mb-3"> -->
         <img src="<?= $product['image']; ?>" class=" img11">
           <!-- <div class="card-body"> -->
           <input type="hidden" name="code" value="<?php echo $product['code']; ?>"/>  
           <h5 class="center pcategory" ><?php echo $product['name']; ?></h5>
           <p class="center">
           <h3>Description:</h3>
           <p><?php echo $product['description']; ?></p>
             <span>₹<?= number_format($product['price'], 2); ?></span><br>
             <input type="number" name="quantity" value="1" size="2"><br><br>
               <input type="submit" id="btn" value="Add to Cart" class="btn btn-sm" style="background-color: rgb(202, 143, 122); border-color:blueviolet; font-weight:650;">
              

           </p>
           <!-- </div> -->
       <!-- </div> -->
</form>
   </div>

  
    
</body>
</html>
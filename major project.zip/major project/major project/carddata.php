<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="detail.css">
    <title>Door Hangings</title>
</head>
<body>
<div class="mydiv">
 <h1>ARTS VILLA</h1>
</div>
<div class="row">
        <div class="col-md-12">
            <h1>Door Hangings</h1>
            <h1>Products List</h1>
            <div class="d-flex"> 
                <div class="card-deck"> 
                    <?php
                      include('connection.php');
                    $query = "SELECT * FROM `mirror`";
                    $product = mysqli_query($conn, $query);
                    if (!empty($product)) {
                        while ($row = mysqli_fetch_array($product)) { ?>
                            <form action="cart.php?action=add&pid=<?= $row['id']; ?>" method="post">
                                <div class="card" style="width: 550px">
                                    <img class="card-img-top"
                                         src="<?= $row['image']; ?>"
                                         alt="<?= $row['name']; ?>"
                                         width="150">
                                    <div class="card-header d-flex justify-content-between">
                                
                                        <span><?= $row['name']; ?></span>
                                        <span>₹<?= number_format($row['price'], 2); ?></span>
                                    </div>
                                    <div class="card-body d-flex">
                                      <p><?= $row['description']; ?></p>
                                    </div>
                                    <div class="card-body d-flex justify-content-between">
                                        
                                        <input type="number" name="quantity" value="1" size="2">
                                        <input type="submit" value="Add to Cart" class="btn btn-success btn-sm">
                                    </div>
                                   
                                </div>
                                
                            </form>
                        <?php }
                    } else {
                        echo "no products available";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
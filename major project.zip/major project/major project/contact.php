<?php
 include('sendemail.php');
 include('headercontact.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alpha Design</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

  <link
    href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Tangerine&family=Tiro+Telugu&display=swap"
    rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Lobster&family=Nunito:wght@500&family=Tiro+Telugu&display=swap" rel="stylesheet">
<link rel="stylesheet" href="index.css">

 

</head>



<body>
  
  <section>
  <div class="row">
   <?php echo $alert;?>
    <div class="col-12 col-md-6 col-lg-6">
        <h2>Contact Info.</h2>
        <p class="textpstyle">Some information that you may want to know</p>
        <p class="textpstyle">
            <i class="fa-solid fa-phone icon"></i>  1234567890
          </p><br>
          <hr  style="color:rgb(197, 57, 85)">
          <p class="textpstyle">
            <i class="fa-solid fa-envelope icon"></i>  alphadesign369@gmail.com
          </p>
         
    </div>
    <div class="col-12 col-md-6 col-lg-6">
        <h2 class="sent-notfication">Leave Your Message</h2>
        <p class="textpstyle">Feel free to contact with us by using the form below</p>
        <div class="row" id="myForm">
            <div class="col-12 col-md-12 col-lg-6"><div class="input-group flex-nowrap">
            <span class="input-group-text bgpink" id="addon-wrapping">@</span>
            <input type="text" id="name" class="form-control" placeholder="Your Name" aria-label="Username" aria-describedby="addon-wrapping">
          </div></div>
          <div class="col-12 col-md-12 col-lg-6">
          <div class="input-group flex-nowrap">
            <span class="input-group-text bgpink" id="addon-wrapping">@</span>
            <input type="email"  id="email"class="form-control" placeholder="Email" aria-label="Username" aria-describedby="addon-wrapping">
          </div>
        </div>
        </div>
        <div class="input-group space">
            <span class="input-group-text bgpink ">Message</span>
            <textarea  id="body"class="form-control" aria-label="With textarea"></textarea><br><br>
            
          </div>
        <button type="submit" class="btn btn-sm btn-danger">Submit</button>
          
    </div>

</div>
</section>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script type="text/javascript">
  if(window.history.replaceState)
  {
    window.history.replaceState(null,null,window.location.href)
  }
</script>
     

<?php
include('footer.php');
?>


      






    





     
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
        crossorigin="anonymous"></script>
      <script src="https://kit.fontawesome.com/76632d8e3c.js" crossorigin="anonymous"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
          integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2"
          crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"
          integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk"
          crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js"
          integrity="sha384-kjU+l4N0Yf4ZOJErLsIcvOU2qSb74wXpOhqTvwVx3OElZRweTnQ6d31fXEoRD1Jy"
          crossorigin="anonymous"></script> 


</body>

</html>
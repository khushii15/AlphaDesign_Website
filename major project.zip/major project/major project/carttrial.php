
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alpha Design</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

  <link
    href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Tangerine&family=Tiro+Telugu&display=swap"
    rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

  <link rel="stylesheet" href="card.css">
  <link rel="stylesheet" href="trial.css">

</head>
<style>
  .brand {
    font-size: 45px;
    font-family: Tangerine, cursive;
    font-weight: bolder;
  }

  .nav-link {
    margin: 0 1vw;
  }

  .navbar {
    margin: 0 auto;
  }

  .logo {
    margin: 0 1vw;
    /* width: 30px; */
    cursor: pointer;
    font-size: 20px;
  }

  .titles {
    margin-top: 3vh;
    font-size: 45px;
    font-weight: 900;
    font-family: Tangerine;
    color: black;
    text-align: center;
  }

  a {
    text-decoration: none;
    color: black;
  }

  a:hover {
    color: black;
  }

  .category {

    padding: 0;

  }
  .category:hover
  {
    opacity: 0.6;
  }


  .container1 {
    margin: 40px 20px;



  }

  .img1 {
    width: 15vw;
  }

  .pcategory {
    margin-top: 25px;
    font-weight: 600;
    margin-bottom: 0px;
  }

  footer {
    margin: 0;
    padding: 0;

  }

  .subtitles {
    text-align: center;
    text-transform: uppercase;
    font-size: small;
    margin-top: -10px;
  }

  .center {
    align-items: center;
    text-align: center;
    /* justify-content: center; */
  }

  .img11{
    width: 250px;
    height: 300px;

  }
  h5{
    font-family: Tangerine, cursive;
  }
  @media (max-width:536px) and (min-width:0px) {
    .img11 {
      width: 45vw;
      height: 50vw;
    }

  }

  /* 766-1024  */
  @media (max-width:990px) and (min-width:750px) {
    .img1 {
      width: 25vw;
    }

  }

  @media (max-width:750px) and (min-width:560px) {
    .img1 {
      width: 29vw;
    }

  }

  @media (max-width:560px) and (min-width:0px) {
    .img1 {
      width: 28vw;
    }

    .pcategory {
      font-size: 10px;

    }

  }
</style>



</style>

<body>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <header>
    <nav class="navbar navbar-expand-lg ">
      <div class="container-fluid">
        <a class="navbar-brand brand" href="#" style="margin-left: 70px;">Alpha Design</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      </div>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active " aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Categories
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Cushion</a></li>
              <li><a class="dropdown-item" href="#">Macrame Miror</a></li>
              <li><a class="dropdown-item" href="#">Wall Hangings</a></li>
              <li><a class="dropdown-item" href="#">Macrame Purse</a></li>
              <li><a class="dropdown-item" href="#">Table cloth</a></li>
              <li><a class="dropdown-item" href="#"> Macramre Flower Vase</a></li>
            </ul>
          </li>
          </li>

          </li>
          <li class="nav-item ">
            <a class="nav-link" href="#">About</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="#">Contact</a>
          </li>

        </ul>
        <a class="login" href="login.php"> <abbr title="Login/Register"><i
              class="fa-solid fa-user logo"></i></abbr></a>

             <abbr title="Cart"><i class="fa-solid fa-cart-shopping logo" ></i></abbr>
             <span>
    

    </nav>
    <hr style="color:rgba(138, 131, 131, 0.752)">
  </header>
  <main>
    <div class="subtitles">passion for home decoration</div>
    <div class="titles">Products</div>
    <div class="container1">
      <div class="row center">
      <?php
                      include('connection.php');
                    $query = "SELECT * FROM `cushion`";
                    $result = mysqli_query($conn, $query);
                    if (!empty($result)) {
                        while ($product = mysqli_fetch_array($result))
                         {
                            ?>
                            <div class="col-sm-6 col-md-4 col-lg-3 ">
                            <form action="cart.php?action=add&pid=<?= $product['id']; ?>" method="post">
                                <div class="card">
                                    <img src="<?= $product['images']; ?>" width="350px" height="350px" alt="images" class="card-img-top">
                                    <div class="card-body">
                                      <input type="hidden" name="code" value="<?php echo $product['code']; ?>"/>  
                                    <h4 class="card-title pcategory"><?php echo $product['name']; ?></h4>
                                    <p class="card-text">
                                      <span>₹<?= number_format($product['price'], 2); ?></span><br>
                                      <input type="number" name="quantity" value="1" size="2"><br><br>
                                        <input type="submit" value="Add to Cart" class="btn btn-success btn-sm">
                                       

                                    </p>
                                    </div>
                                </div>
                         </form>
                            </div>

                            <?php

                            
                         }
                        }
                        else {
                            echo "no products available";
                        }
                             ?>
        </div> 
            </div>
            </div>
            </div>
            </div>



   
   




      <footer class="bg-dark text-white pt-4 pb-6">
        <div class="container text-center text-md-left">
          <div class="row text-center text-md-left">
            <div class="col-md-6 col-lg-6 col-xl-6 mx-auto mt-6">
              <h5 class="text-uppercase mb-4 font-weight-bolder text-danger" >Alpha Design</h5>
              <p>"Design is coming to grips with one's real lifestyle, one's real place in the world. rooms should not
                be put together for show but to nourish one's well-being."</p>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-6 mx-auto mt-6">
              <h5 class="text-uppercase mb-4 font-weight-bold text-danger">contact us</h5>

              <span style="color:white;">
                <i class="fa-solid fa-envelope"></i>
              </span>songirkar@gmail.com
              <br>

              <span style="color:white;">
                <i class="fa-solid fa-phone"></i>
              </span>123456789

              <div class="text-center text-md-right">
                <ul class="list-unstyled list-item">
                  <li class="list-inline-item">

                    <a href="#" class="btn-floating btn-sm text-white" style="font-size: 23px; color: crimson;"><i
                        class="fa fa-facebook"></i></a>
                  </li>
                  <li class="list-inline-item">

                    <a href="#" class="btn-floating btn-sm text-white" style="font-size: 23px;  color: crimson;"><i
                        class="fa fa-google"></i></a>
                  </li>
                  <li class="list-inline-item">
                    <a href="#" class="btn-floating btn-sm text-white" style="font-size: 23px;  color: crimson;"><i
                        class="fa fa-youtube"></i></a>
                  </li>
                </ul>
              </div>

            </div>


          </div>
        </div>



      </footer>






      <!-- <footer>
      <div class="container-fluid p-0">
          <div class="row text-left">
              <div class="col-md-5">
                  <h1 class="text-light">About us</h1>
                  <p class=" text-muted ">
                    "Design is coming to grips with one's real lifestyle, one's real place in the world. rooms should not be put together for show but to nourish one's well-being."
                  </p>
              </div>
              <div class="col-md-5">
                  <h4 class="text-light">Newsletter</h4>
                  <p class="text-muted">Stay Updated</p>
                  <form class="form-inline">
                      <div class="col pl-">
                          <div class="input-group pr-5">
                              <input type="text" class="form-control bg-dark text-white" placeholder="Email">
                              <div class="input-group-prepend">
                              <div class="input-group-text">
                                  <i class="fas fa-arrow-right"></i>                                    </div>
                              </div>
                          </div>
                      </div>
                  </form>
              </div>
              <div class="col-md-2">
                  <h4 class="text-light">Contact us</h4>
                  <p>
                      <i class="fas fa-home mr-3"></i>  Pratappura, Burhanpur 450331
                    </p>
                    <p>
                      <i class="fas fa-envelope mr-3"></i>   alphadesign369@gmail.com
                    </p>
                    <p>
                      <i class="fas fa-phone mr-3"></i>  1234567890
                    </p>
              </div>
          </div>
      </div>
  </footer> -->





      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
        crossorigin="anonymous"></script>
      <script src="https://kit.fontawesome.com/76632d8e3c.js" crossorigin="anonymous"></script>
      <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
          integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2"
          crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"
          integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk"
          crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js"
          integrity="sha384-kjU+l4N0Yf4ZOJErLsIcvOU2qSb74wXpOhqTvwVx3OElZRweTnQ6d31fXEoRD1Jy"
          crossorigin="anonymous"></script> -->


</body>
</html>

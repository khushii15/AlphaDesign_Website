



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="signupp.css">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <section>
       
        <div class="contentBx">
            <div class="formBx">
                <h2>Signup</h2>
                <form action="" method="POST">
                    <div class="inputBx">
                        <span>Username</span>
                        <input type="text" name="username" placeholder="Enter Your Name here" required>
                   
                    </div>
                    <div class="inputBx">
                        <span>Email</span>
                        <input type="email" name="email" placeholder="Enter Your Email here" required>
                   
                    </div>
                    <div class="inputBx">
                        <span>Password</span>
                        <input type="password" name="password" placeholder="Enter Password" required>
                   
                    </div>
                    <div class="inputBx">
                        <span> Confirm Password</span>
                        <input type="password" name="cpassword" placeholder="Confirm Password" required>
                   
                    </div>
                   
                    <div class="inputBx">
                    <button name="submit" >Register</button>
                        <!-- <input type="submit" value="Sign in" name=""> -->

                    </div>
                    <?php
include("connection.php");
if(isset($_POST['submit']))
{
  $username = $_POST['username'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $cpassword = $_POST['cpassword'];

  if($password == $cpassword)
  {
    $sql = "SELECT * FROM register WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $sql);
    if(!$result -> num_rows > 0)
    {
      $sql = "INSERT INTO register (username,email,password) VALUES ('$username','$email','$password')";
      $result = mysqli_query($conn,$sql);
      if($result)
      {
          echo "<h4 style='color:green;'>'Registration Completed'</h4>";
      }
      else
      {
        echo "<h4 style='color:red;'>'Something Went Wrong'</h4>";
      }
    }
    else
    {
      echo "<h4 style='color:yellow;'>'This email already exists'</h4>";
    }
  }
  else
  {
    echo "<h4 style='color:red;'>'Password not matched'</h4>";
  }
}

?>
                    <div class="inputBx">
                        <p>Already have an accout?  <a href="login.php">Sign in</a></p>
                    </div>
                    
                </form>
                <h3>Login with social media</h3>
                <ul class="sci">
                    <li><i class="fa-brands fa-facebook"></i></li>
                    <li><i class="fa-brands fa-instagram"></i></li>
                    <li><i class="fa-brands fa-google"></i></li>
                </ul>

            </div>

        </div>
        <div class="imgBx">
            <img src="images/home.jpg">
        </div>
    </section>
    
</body>
</html>
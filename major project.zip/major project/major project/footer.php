<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
<footer>
      <div class="container-fluid p-0">
          <div class="row text-left">
              <div class="col-md-5">
                  <h1 class="textblack">About us</h1>
                  <p class="textstyle">
                    "Design is coming to grips with one's real lifestyle, one's real place in the world. rooms should not be put together for show but to nourish one's well-being."
                  </p>
              </div>
              <div class="col-md-3">
                  <h4 class="textblack">Contact us</h4>
                  <p>
                      <i class="fas fa-home mr-3"></i>  Pratappura, Burhanpur 450331
                    </p>
                    <p>
                      <i class="fas fa-envelope mr-3"></i>   alphadesign369@gmail.com
                    </p>
                    <p>
                      <i class="fas fa-phone mr-3"></i>  1234567890
                    </p>
              </div>
            
              <div class="col-md-3">
                  <h4 class="textblack">Newsletter</h4>
                  <p class="textstyle">Stay Updated</p>
                  <form class="form-inline">
                      <div class="col pl-3">
                          <div class="input-group pr-3">
                              <input type="text" class="form-control text-white bgpink" placeholder="Email">
                              <div class="input-group-prepend">
                              <div class="input-group-text">
                                  <i class="fas fa-arrow-right"></i>                                    
                                </div>
                              </div>
                          </div>
                      </div>
                  </form>
              </div>
              
              
              
          </div>
      </div>
  </footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
        crossorigin="anonymous"></script>
      <script src="https://kit.fontawesome.com/76632d8e3c.js" crossorigin="anonymous"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
          integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2"
          crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"
          integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk"
          crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js"
          integrity="sha384-kjU+l4N0Yf4ZOJErLsIcvOU2qSb74wXpOhqTvwVx3OElZRweTnQ6d31fXEoRD1Jy"
          crossorigin="anonymous"></script> 



</body>
</html>
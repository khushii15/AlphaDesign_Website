<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>pinterest</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

  <link
    href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Tangerine&family=Tiro+Telugu&display=swap"
    rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

  <link rel="stylesheet" href="card.css">
  <link rel="stylesheet" href="trial.css">

</head>
<style>
  .brand {
    font-size: 45px;
    font-family: Tangerine, cursive;
    font-weight: bolder;
  }

  .nav-link {
    margin: 0 1vw;
  }

  .navbar {
    margin: 0 auto;
  }

  .logo {
    margin: 0 1vw;
    /* width: 30px; */
    cursor: pointer;
    font-size: 20px;
  }

  .titles {
    margin-top: 3vh;
    font-size: 45px;
    font-weight: 900;
    font-family: Tangerine;
    color: black;
    text-align: center;
  }

  a {
    text-decoration: none;
    color: black;
  }

  a:hover {
    color: black;
  }

  .category {

    padding: 0;

  }
  .category:hover
  {
    opacity: 0.6;
  }


  .container1 {
    margin: 40px 20px;



  }

  .img1 {
    width: 15vw;
  }

  .pcategory {
    margin-top: 25px;
    font-weight: 600;
    margin-bottom: 0px;
  }

  footer {
    margin: 0;
    padding: 0;

  }

  .subtitles {
    text-align: center;
    text-transform: uppercase;
    font-size: small;
    margin-top: -10px;
  }

  .center {
    align-items: center;
    text-align: center;
    /* justify-content: center; */
  }

  .img11{
    width: 250px;
    height: 300px;

  }
  h5{
    font-family: Tangerine, cursive;
  }
  @media (max-width:536px) and (min-width:0px) {
    .img11 {
      width: 45vw;
      height: 50vw;
    }

  }

  /* 766-1024  */
  @media (max-width:990px) and (min-width:750px) {
    .img1 {
      width: 25vw;
    }

  }

  @media (max-width:750px) and (min-width:560px) {
    .img1 {
      width: 29vw;
    }

  }

  @media (max-width:560px) and (min-width:0px) {
    .img1 {
      width: 28vw;
    }

    .pcategory {
      font-size: 10px;

    }

  }
</style>



</style>

<body>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <header>
    <nav class="navbar navbar-expand-lg ">
      <div class="container-fluid">
        <a class="navbar-brand brand" href="#" style="margin-left: 70px;">Alpha Design</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      </div>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active " aria-current="page" href="#">Home</a>
          </li>
          <!-- <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Categories
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Cushion</a></li>
              <li><a class="dropdown-item" href="#">Macrame Miror</a></li>
              <li><a class="dropdown-item" href="#">Wall Hangings</a></li>
              <li><a class="dropdown-item" href="#">Macrame Purse</a></li>
              <li><a class="dropdown-item" href="#">Table cloth</a></li>
              <li><a class="dropdown-item" href="#"> Macramre Flower Vase</a></li>
            </ul>
          </li>
          </li>

          </li>
          <li class="nav-item ">
            <a class="nav-link" href="#">About</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="#">Contact</a>
          </li>

        </ul>
        <a class="login" href="login.php"> <abbr title="Login/Register"><i
              class="fa-solid fa-user logo"></i></abbr></a>

              <a class="login" href="cart.php"> <abbr title="Cart"><i class="fa-solid fa-cart-shopping logo"  ></i></abbr></a>
            
                   -->


      </div>

    </nav>
    <hr style="color:rgba(138, 131, 131, 0.752)">
  </header>
  <div class="container-fluid bg-light">
    <div class="row dn">
      <div class="col">
        <img src="images/cr6.jpg" class="design_image" width="500px" height="500px">
      </div>
      <div class="col">
        <h2> Design your<br>
          Custom home decors<br>
          with Alpha Design</h2>
          <p class="dnp">A new revolution. A new perspective.</p>
        <a href="contact.php">  <button type="button" class="btn btn-danger">Design Now</button></a>
        </div>
    </div>
    </div><br>
    <?php
  include('footer.php');
  ?>
 
</body>

<html>
<!-- <?php
include("connection.php");
if(isset($_POST['submit']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM  register WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $sql);
    if($result -> num_rows>0)
    {
        $row = mysqli_fetch_assoc($result);
        echo "<h4>'You are Logged in!!'</h4>";
    }
    else{
        echo "<script>alert('Email or Password is wrong!!')</script>";
    }
}
?> -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="loginpage.css">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <section>
        <div class="imgBx">
            <img src="images/home3.jpg">
        </div>
        <div class="contentBx">
            <div class="formBx">
                <h2>Login</h2>
                <form action="" method="POST">
                    <!-- <div class="inputBx">
                        <span>Username</span>
                        <input type="text" name="">
                   
                    </div> -->
                     <div class="inputBx">
                        <span>Email</span>
                        <input type="email" name="email" placeholder="Enter Email" required>
                   
                    </div> 
                    <div class="inputBx">
                        <span>Password</span>
                        <input type="password" name="password" placeholder="Enter password" required>
                   
                    </div>
                    <div class="remember">
                        <label>
                            <input type="checkbox" name="">Remember me
                        </label>
                    </div>
                    <div class="inputBx">
                        <button name="submit">Login</button>
                        <!-- <input type="submit" value="Sign in" name=""> -->
                        <?php
                        include("connection.php");
                        if(isset($_POST['submit']))
                        {
                            $email = $_POST['email'];
                            $password = $_POST['password'];
                            $sql = "SELECT * FROM  register WHERE email = '$email' AND password = '$password'";
                            $result = mysqli_query($conn, $sql);
                         if($result -> num_rows>0)
                         {
                             $row = mysqli_fetch_assoc($result);
                             echo "<h4 style='color:green;'>'You are Logged in!!'</h4>";
                             header('Location: customize.php');
                         }
                         else{
                             echo "<h4 style='color:red;'>'Email Or password is wrong !!'</h4>";
                         }
                        }
                        ?>
                    </div>
                    <div class="inputBx">
                        <p>Don't have an account? <a href="register.php">Sign up</a></p>
                    </div>
                    
                </form>
                <h3>Login with social media</h3>
                <ul class="sci">
                    <li><i class="fa-brands fa-facebook"></i></li>
                    <li><i class="fa-brands fa-instagram"></i></li>
                    <li><i class="fa-brands fa-google"></i></li>
                </ul>

            </div>
        </div>
    </section>
    
</body>
</html>


